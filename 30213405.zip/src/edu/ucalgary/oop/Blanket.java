package edu.ucalgary.oop;

public class Blanket extends Supply {
    public Blanket(int ID) {
        super(ID, "blanket");
    }
}
