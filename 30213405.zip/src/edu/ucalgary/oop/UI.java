package edu.ucalgary.oop;

import javax.swing.JPanel;

public interface UI {
    public JPanel getPanel();
}
